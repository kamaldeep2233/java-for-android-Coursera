package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Divide operation.
 */
public class Divide {
    // TODO -- start your code here

    private int argOne=0;
    private int argTwo=0;

    public Divide(int argumentOne ,int argumentTwo ){
        this.argOne=argumentOne;
        this.argTwo=argumentTwo;
    }

    public String toString(){
        return String.valueOf(argOne/argTwo) +
                " R :" + String.valueOf(argOne%argTwo);
    }
}
